// server.js
// Node.js backend salvo do projeto (copiado da canvas atual)
[INSERIR CONTEÚDO DO SERVER.JS AQUI]
